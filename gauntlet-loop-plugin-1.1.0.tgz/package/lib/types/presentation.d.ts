import type { GauntletResult } from './core.js';
export declare function renderDashboard(result: GauntletResult): string;
export declare function renderToolValue(value: unknown): string;
//# sourceMappingURL=presentation.d.ts.map