/**
 * Pure reconstruction of a canonical GauntletState from the durable session
 * event log.  Every successful `gauntlet_loop` tool call is recorded in the
 * session log as a `tool/call` event (with raw arguments) followed by a
 * `tool/result` event.  This module folds the SETTLED calls through
 * `runGauntletAction` to reproduce the canonical state — the one and only
 * state machine (src/core.ts) stays the authority.
 *
 * The session log IS the durable source of truth; no second store, no custom
 * event types, no ad-hoc JSON files.  Reconstruction is deterministic: given
 * the same event log, the same state is produced every time (the `now`
 * argument is derived from `event.time`, which is stable).
 *
 * FAIL-CLOSED VERIFICATION: every settled call carries a `tool/result` whose
 * `meta` (persisted by the harness via the tool's `presentationMeta`) records
 * the protocol version and a semantic fingerprint of the post-action state.
 * Replay recomputes that fingerprint from the reproduced state and fails
 * closed if it diverges — a tampered call, an incompatible protocol version,
 * or a stale log without verification metadata can never silently normalize
 * into a valid Gauntlet.
 *
 * INCREMENTAL FOLD: the fold is resumable.  A {@link ReplayCheckpoint} lets a
 * caller carry the fold forward across growing logs (per-session watermark),
 * so live calls and invariants re-fold only the delta instead of the whole
 * history.  The checkpoint is a pure cache — every settled call it resumes
 * from is still verified against its persisted meta.
 *
 * A `tool/call` without a matching settled `tool/result` is treated as
 * in-flight (the agent loop appends the result only after the tool returns),
 * so reconstruction never double-applies the action being executed right now.
 *
 * @module gauntlet-loop-plugin/replay
 */
import { type GauntletActionInput, type GauntletState } from './core.js';
/**
 * The verification meta the gauntlet tool persists on every settled
 * `tool/result` (via its `output.presentationMeta`).  The harness stores it in
 * `tool/result.data.meta` and replay compares against it.
 */
export interface GauntletResultMeta {
    /** The fold-semantics version that produced this result. */
    protocol: number;
    /** The state-shape version that produced this result. */
    schema: number;
    /** Whether the original call was accepted by the core. */
    ok: boolean;
    /** Semantic fingerprint of the post-action state (`stateFingerprint`). */
    fingerprint: string | null;
}
/** One pending in-flight gauntlet call (tool/call seen, tool/result not yet). */
export interface PendingCall {
    args: GauntletActionInput;
    time: number;
}
/**
 * A resumable fold position: the seq up to which `state` is current, plus the
 * in-flight calls that were seen as `tool/call` but not yet settled.  A pure
 * cache — never a source of truth, always re-verifiable from the log.
 */
export interface ReplayCheckpoint {
    lastSeq: number;
    state: GauntletState;
    pending: Record<string, PendingCall>;
}
/** Result of one reconstruction pass. */
export interface ReplayOutcome {
    /** The reconstructed state (fails closed via `error`). */
    state: GauntletState;
    /** Set when reconstruction cannot be proven safe. */
    error?: {
        kind: string;
        detail: string;
    };
    /** The new fold position to cache for an incremental next pass. */
    checkpoint?: ReplayCheckpoint;
}
/**
 * Per-session fold checkpoint cache keyed by the **Session instance identity**
 * (`WeakMap`), NOT by `session.id`.  This ensures a new Session incarnation
 * (same id, different instance) always starts with a clean checkpoint and
 * re-verifies the full history — the cache can never accidentally become a
 * source of truth across incarnations.
 */
export declare class ReplayCheckpointCache {
    private readonly map;
    /** Retrieve the cached checkpoint for `session`, or `undefined` on a miss. */
    get(session: object): ReplayCheckpoint | undefined;
    /** Store a checkpoint for `session`. */
    set(session: object, checkpoint: ReplayCheckpoint): void;
}
/** Parse the raw `arguments` JSON string from a `tool/call` event into an action input. */
export declare function parseCallArguments(raw: unknown): GauntletActionInput;
/**
 * Reconstruct the canonical GauntletState by replaying SETTLED `gauntlet_loop`
 * tool calls from the session event log.  Settled = a `tool/call` followed by
 * a matching non-aborted `tool/result`.  An in-flight call (call without
 * result) is skipped.
 *
 * When `checkpoint` is provided and its `lastSeq` is within the log, the fold
 * resumes from that position (seeding state + in-flight calls) and only folds
 * the delta.  Every settled call folded — resumed or fresh — is verified
 * against its persisted result meta; any divergence fails closed.
 *
 * @param events - the session's append-only event list (in seq order).
 * @param checkpoint - optional prior fold position to resume from.
 * @returns the reconstructed state (plus `error` when unverifiable) and the
 *   next checkpoint.
 */
export declare function reconstructFromSessionEvents(events: readonly {
    type: string;
    time: number;
    data?: unknown;
}[], checkpoint?: ReplayCheckpoint): ReplayOutcome;
/**
 * Find the `tool/call` event time for a callId, if the call has already been
 * logged.  Used so a live action and its later replay share the same `now`.
 */
export declare function findCallTime(events: readonly {
    type: string;
    time: number;
    data?: unknown;
}[], callId: string): number | undefined;
/**
 * Validate a reconstructed GauntletState against cross-field invariants.
 * Returns an array of error messages (empty = valid).
 * This is a pure, deterministic check that does NOT re-run the state machine.
 */
export declare function validateReconstructedState(state: GauntletState): string[];
//# sourceMappingURL=replay.d.ts.map