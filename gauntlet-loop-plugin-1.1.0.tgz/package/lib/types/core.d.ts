export type GauntletPhase = 'idle' | 'refine' | 'split' | 'loop' | 'report' | 'done' | 'halted';
export type PieceStatus = 'pending' | 'awaiting_critique' | 'rebuild' | 'won';
/**
 * Version of the protocol FOLD semantics — the rules in `runGauntletAction`
 * that turn one settled call into the next state.  Bump this constant whenever
 * those rules change in a way that could produce a different state for the
 * same inputs: a persisted log written under an older version must then fail
 * closed at reconstruction instead of being silently replayed under new rules.
 */
export declare const GAUNTLET_PROTOCOL_VERSION = 1;
/**
 * Version of the `GauntletState` SHAPE (schemaVersion field).  Bump when the
 * serialized state fields change.  Distinct from the fold-semantics version:
 * a state-shape change also requires a protocol-semantics review.
 */
export declare const GAUNTLET_SCHEMA_VERSION = 2;
export interface QualityBar {
    name: string;
    fetchHow: string;
    compareHow: string;
    description: string;
}
export interface Artifact {
    location: string;
    summary: string;
}
export interface CriticVerdict {
    winner: 'ours' | 'bar';
    notes: string;
    evidence: string;
    blind: true;
    criticSubagentId: string;
}
export interface RoundState {
    round: number;
    artifact: Artifact;
    builderSubagentId: string;
    builderEvidence: string;
    verdict: CriticVerdict | null;
}
export interface PieceState {
    id: string;
    title: string;
    status: PieceStatus;
    rounds: RoundState[];
}
export interface GauntletState {
    schemaVersion: typeof GAUNTLET_SCHEMA_VERSION;
    protocolVersion: typeof GAUNTLET_PROTOCOL_VERSION;
    runId: string | null;
    phase: GauntletPhase;
    rawCommand: string | null;
    refinedCommand: string | null;
    bar: QualityBar | null;
    subjectivity: {
        flagged: string[];
        resolved: {
            term: string;
            objectiveDefinition: string;
            measuredBy: string;
        }[];
    } | null;
    refineRejections: {
        refined: string;
        bar: unknown;
        reasons: string[];
        flagged: string[];
        at: number;
    }[];
    pieces: {
        id: string;
        title: string;
        description: string;
    }[];
    piecesState: PieceState[];
    startedAt: number | null;
    finishedAt: number | null;
    summary: {
        outcome: string;
        lessons: string;
    } | null;
    haltedReason: string | null;
}
export interface GauntletActionInput {
    action: string;
    command?: unknown;
    refinedCommand?: unknown;
    bar?: unknown;
    subjectiveResolved?: unknown;
    pieces?: unknown;
    pieceIndex?: unknown;
    builderSubagentId?: unknown;
    builderEvidence?: unknown;
    artifact?: unknown;
    criticSubagentId?: unknown;
    verdict?: unknown;
    summary?: unknown;
    reason?: unknown;
}
export interface GauntletActionContext {
    now: number;
    runId?: string;
}
export interface GauntletResult {
    ok: boolean;
    phase: GauntletPhase;
    message?: string;
    error?: string;
    rejections?: string[];
    next: string | null;
    nextPieceIndex?: number;
    state: GauntletState;
}
export declare function findSubjectiveTerms(input: string): string[];
export declare function createInitialState(): GauntletState;
/**
 * Deterministic semantic fingerprint of a GauntletState, used to verify that a
 * replayed settled call reproduces the exact result that was originally
 * persisted.  Excludes volatile timestamps (`startedAt`, `finishedAt`,
 * `refineRejections[].at`) and the envelope versions (checked separately via
 * the persisted meta), so live execution and replay agree byte-for-byte even
 * when the harness stamps slightly different wall-clock times.  Every field
 * that shapes the protocol's next transition is included, so any tampering
 * that changes a call's semantics produces a different fingerprint.
 *
 * Returns a FIXED-SIZE SHA-256 hex digest of a canonical (deterministically
 * key-sorted) JSON representation — never the whole state JSON.  This keeps
 * the persisted `tool/result.meta` constant-sized regardless of how large the
 * accumulated state grows (no O(n²) write amplification).
 */
export declare function stateFingerprint(state: GauntletState): string;
export declare function runGauntletAction(state: GauntletState, input: GauntletActionInput, context: GauntletActionContext): GauntletResult;
//# sourceMappingURL=core.d.ts.map