/**
 * Stateful Gauntlet Loop protocol for DeepSeek Harness.
 *
 * The tool reconstructs its canonical state from the durable session event log
 * by replaying every settled `gauntlet_loop` tool call through the pure core
 * state machine (`src/core.ts`).  No in-memory mutable state is maintained
 * between calls — the session event log IS the durable source of truth.
 *
 * Every successful call persists a verification `meta` on its `tool/result`
 * (protocol version + semantic fingerprint of the post-action state).  On
 * restart/reload the session log is replayed from persistence (JSONL/SQLite);
 * the first tool call after reload reconstructs the exact pre-restart state
 * and FAILS CLOSED if any settled call does not reproduce its persisted result
 * (tampering, incompatible protocol version, or a stale log without meta).
 *
 * The live fold is incremental: a per-session watermark checkpoint re-folds
 * only the delta on each call, while the full deterministic replay remains
 * available for verification and tests.
 *
 * Cross-session isolation is guaranteed: each session has its own event log
 * and its own fold checkpoint.  The 'anonymous' fallback is removed — a tool
 * call without an owning agent session is rejected.
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-gauntlet";
export declare const inject: string[];
/** Register the `gauntlet_loop` model-facing tool. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map